/// VPS API 地址
/// 开发时可以用 localhost，发行版用公网 IP
class ApiConfig {
  static const baseUrl = 'http://120.26.116.220:8080';
}
